<?php
/*
Plugin Name: River Core
Description: Plugin that adds additional features needed by our theme
Author: Qode Themes
Version: 1.1
*/
if ( ! class_exists( 'RiverCore' ) ) {
	class RiverCore {
		private static $instance;
		
		public function __construct() {
			require_once 'constants.php';
			require_once 'helpers/helper.php';
			
			// Make plugin available for translation
			add_action( 'plugins_loaded', array( $this, 'load_plugin_textdomain' ) );
			
			// Add plugin's body classes
			add_filter( 'body_class', array( $this, 'add_body_classes' ) );
			
			add_action( 'after_setup_theme', array( $this, 'init' ), 5 );
		}
		
		public static function get_instance() {
			if ( self::$instance == null ) {
				self::$instance = new self();
			}
			
			return self::$instance;
		}
		
		function load_plugin_textdomain() {
			load_plugin_textdomain( 'river-core', false, RIVER_CORE_REL_PATH . '/languages' );
		}
		
		function add_body_classes( $classes ) {
			$classes[] = 'river-core-' . RIVER_CORE_VERSION;
			
			return $classes;
		}
		
		function init() {
			
			if ( river_core_is_installed( 'theme' ) ) {
				include_once RIVER_CORE_MODULES_PATH . '/helper.php';
			}
		}
	}
	
	RiverCore::get_instance();
}