<?php

/* Create Portfolio post type */

if ( ! function_exists( 'river_core_create_post_type' ) ) {
	function river_core_create_post_type() {
		$global_options = river_qode_return_global_options();
		$slug = 'portfolio_page';
		
		if ( isset( $global_options['portfolio_single_slug'] ) && $global_options['portfolio_single_slug'] != "" ) {
			$slug = $global_options['portfolio_single_slug'];
		}
		
		register_post_type( 'portfolio_page',
			array(
				'labels'        => array(
					'name'          => esc_html__( 'Portfolio', 'river-core' ),
					'singular_name' => esc_html__( 'Portfolio Item', 'river-core' ),
					'add_item'      => esc_html__( 'New Portfolio Item', 'river-core' ),
					'add_new_item'  => esc_html__( 'Add New Portfolio Item', 'river-core' ),
					'edit_item'     => esc_html__( 'Edit Portfolio Item', 'river-core' )
				),
				'public'        => true,
				'has_archive'   => true,
				'rewrite'       => array( 'slug' => $slug ),
				'menu_position' => 4,
				'show_ui'       => true,
				'supports'      => array( 'author', 'title', 'editor', 'thumbnail', 'excerpt', 'page-attributes' )
			)
		);
		
		register_post_type( 'testimonials',
			array(
				'labels'        => array(
					'name'          => esc_html__( 'Testimonials', 'river-core' ),
					'singular_name' => esc_html__( 'Testimonial', 'river-core' ),
					'add_item'      => esc_html__( 'New Testimonial', 'river-core' ),
					'add_new_item'  => esc_html__( 'Add New Testimonial', 'river-core' ),
					'edit_item'     => esc_html__( 'Edit Testimonial', 'river-core' )
				),
				'public'        => false,
				'show_in_menu'  => true,
				'rewrite'       => array( 'slug' => 'testimonials' ),
				'menu_position' => 4,
				'show_ui'       => true,
				'has_archive'   => false,
				'hierarchical'  => false,
				'supports'      => array( 'title' )
			)
		);
		
		$labels = array(
			'name'              => esc_html__( 'Portfolio Categories', 'river-core' ),
			'singular_name'     => esc_html__( 'Portfolio Category', 'river-core' ),
			'search_items'      => esc_html__( 'Search Portfolio Categories', 'river-core' ),
			'all_items'         => esc_html__( 'All Portfolio Categories', 'river-core' ),
			'parent_item'       => esc_html__( 'Parent Portfolio Category', 'river-core' ),
			'parent_item_colon' => esc_html__( 'Parent Portfolio Category:', 'river-core' ),
			'edit_item'         => esc_html__( 'Edit Portfolio Category', 'river-core' ),
			'update_item'       => esc_html__( 'Update Portfolio Category', 'river-core' ),
			'add_new_item'      => esc_html__( 'Add New Portfolio Category', 'river-core' ),
			'new_item_name'     => esc_html__( 'New Portfolio Category Name', 'river-core' ),
			'menu_name'         => esc_html__( 'Portfolio Categories', 'river-core' ),
		);
		
		register_taxonomy( 'portfolio_category', array( 'portfolio_page' ), array(
			'hierarchical' => true,
			'labels'       => $labels,
			'show_ui'      => true,
			'query_var'    => true,
			'rewrite'      => array( 'slug' => 'portfolio-category' ),
		) );
		
		$labels = array(
			'name'              => esc_html__( 'Testimonials Categories', 'river-core' ),
			'singular_name'     => esc_html__( 'Testimonial Category', 'river-core' ),
			'search_items'      => esc_html__( 'Search Testimonials Categories', 'river-core' ),
			'all_items'         => esc_html__( 'All Testimonials Categories', 'river-core' ),
			'parent_item'       => esc_html__( 'Parent Testimonial Category', 'river-core' ),
			'parent_item_colon' => esc_html__( 'Parent Testimonial Category:', 'river-core' ),
			'edit_item'         => esc_html__( 'Edit Testimonials Category', 'river-core' ),
			'update_item'       => esc_html__( 'Update Testimonials Category', 'river-core' ),
			'add_new_item'      => esc_html__( 'Add New Testimonials Category', 'river-core' ),
			'new_item_name'     => esc_html__( 'New Testimonials Category Name', 'river-core' ),
			'menu_name'         => esc_html__( 'Testimonials Categories', 'river-core' ),
		);
		
		register_taxonomy( 'testimonials_category', array( 'testimonials' ), array(
			'hierarchical'      => true,
			'labels'            => $labels,
			'show_ui'           => true,
			'query_var'         => true,
			'show_admin_column' => true,
			'rewrite'           => array( 'slug' => 'testimonials-category' ),
		) );
	}
	
	add_action( 'init', 'river_core_create_post_type', 0 );
}