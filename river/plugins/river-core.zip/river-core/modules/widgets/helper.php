<?php

if ( ! function_exists( 'river_core_register_widgets' ) ) {
	function river_core_register_widgets() {
		register_widget( 'Call_To_Action' );
		register_widget( 'Qode_Flickr_Widget' );
		register_widget( 'Latest_Posts_Menu' );
		register_widget( 'Related_Posts' );
	}
	
	add_action( 'widgets_init', 'river_core_register_widgets' );
}