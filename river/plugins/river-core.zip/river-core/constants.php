<?php

define( 'RIVER_CORE_VERSION', '1.1' );
define( 'RIVER_CORE_ABS_PATH', dirname( __FILE__ ) );
define( 'RIVER_CORE_REL_PATH', dirname( plugin_basename( __FILE__ ) ) );
define( 'RIVER_CORE_URL_PATH', plugin_dir_url( __FILE__ ) );
define( 'RIVER_CORE_MODULES_PATH', RIVER_CORE_ABS_PATH . '/modules' );
define( 'RIVER_CORE_MODULES_URL_PATH', RIVER_CORE_URL_PATH . 'modules' );